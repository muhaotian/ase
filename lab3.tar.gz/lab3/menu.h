/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014 */
/* */
/* FILE NAME : menu.c */
/* PRINCIPAL AUTHOR : MuHaotian */
/* SUBSYSTEM NAME : menu */
/* MODULE NAME : menu */
/* LANGUAGE : C */
/* TARGET ENVIRONMENT : Ubuntu gcc */
/* DATE OF FIRST RELEASE : 2014/9/23 */
/* DESCRIPTION : This is a menu program */
/**************************************************************************************************/
/*
* Revision log:
*
* Created by MuHaotian,2014/9/23
*
*/
#ifndef _MENU_H_
#define _MENU_H_
#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 10
/* data struct and its operations */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char* cmd;
    char* desc;
    int (*handler)();
} DataNode;
/* find a cmd in the linklist and return the datanode pointer */
DataNode* FindCmd(tLinkTable * head, char * cmd);

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head);

#endif /* _MENU_H_ */


