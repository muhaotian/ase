#include <stdio.h>
#include "linktable.h"
#include "linktable.c"
#include "menu.h"

#define debug

int results[3] = {1,1,1};
char * info[3] =
{
    {"test report"},
    {"TC1 FindCmd"},
    {"TC2 ShowAllCmd"}
};

int main()
{
    int i;
    tLinkTable *head = CreateLinkTable();
    char cmd[CMD_MAX_LEN];
    DataNode *p = FindCmd(head,cmd);
    if(p == NULL)
    {
        debug("TC1 Succ\n");
        results[1] = 0;
    }
    int ret = ShowAllCmd(head);
    if(ret == 0)
    {
        debug("TC2 Succ\n");
        results[2] = 0;
    }
    /* test report */
    printf("test report\n");
    for(i=1;i<=2;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
        if(results[i] == 0)
        {
            printf("Testcase Number%d Succ - %s\n",i,info[i]);
        }
    }
}
