/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014 */
/* */
/* FILE NAME : menu.c */
/* PRINCIPAL AUTHOR : MuHaotian */
/* SUBSYSTEM NAME : menu */
/* MODULE NAME : menu */
/* LANGUAGE : C */
/* TARGET ENVIRONMENT : Ubuntu gcc */
/* DATE OF FIRST RELEASE : 2014/9/23 */
/* DESCRIPTION : This is a menu program */
/**************************************************************************************************/
/*
* Revision log:
*
* Created by MuHaotian,2014/9/23
*
*/
#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 10
/* data struct and its operations */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char* cmd;
    char* desc;
    int (*handler)();
} DataNode;
/* find a cmd in the linklist and return the datanode pointer */
DataNode* FindCmd(tLinkTable * head, char * cmd)
{
    DataNode * pNode = (DataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return pNode;
        }
        pNode = (DataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}
/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * head)
{
    DataNode * pNode = (DataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (DataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}
tLinkTable * head = NULL;
int Help()
{
    ShowAllCmd(head);
    return 0;
}
/* menu program */
static DataNode data[] =
{
    {NULL, "help", "this is help cmd!", Help},
    {NULL, "version", "menu program v1.0", NULL}
};

main()
{
    head = CreateLinkTable();
    AddLinkTableNode(head,(tLinkTableNode *)&data[0]);
    AddLinkTableNode(head,(tLinkTableNode *)&data[1]);
/* cmd line begins */
    ShowAllCmd(head);
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd number > ");
        scanf("%s", cmd);
        DataNode *p = FindCmd(head, cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        if(p->handler != NULL)
        {
            p->handler();
        }
    }
}
