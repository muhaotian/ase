This is a menu program!
Build Procedure
$ gcc linktable.c menu.c -o menu
$ ./menu # you can input help/version cmd.

TARGET ENVIRONMENT : Ubuntu gcc
If you want to run the program on Microsoft Visual C++,please install <pthread.h> first.
